INSERT INTO subreddit_moderator (user_id, subreddit_id) VALUES
(4, 1),
(5, 1),
(17, 10),
(2, 2),
(8, 3),
(9, 4),
(6, 5),
(7, 6),
(6, 7),
(20, 8),
(19, 9);
